import { onCall, HttpsError } from "firebase-functions/v2/https";
import * as admin from "firebase-admin";

admin.initializeApp();

const bucket = admin.storage().bucket();
const FILE_PATH = "data-web/data_backup.json";

export const downloadFamilyData = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Login required");
  }

  const file = bucket.file(FILE_PATH);
  const [exists] = await file.exists();

  if (!exists) {
    throw new HttpsError("not-found", "Data file not found");
  }

  const [contents] = await file.download();
  const [metadata] = await file.getMetadata();

  return {
    ...JSON.parse(contents.toString()),
    _version: metadata.updated,
  };
});


export const uploadFamilyData = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Login required");
  }

  const data = request.data;

  if (!data?.familyTree_members || !data?.familyTree_relations) {
    throw new HttpsError("invalid-argument", "Invalid format");
  }

  const file = bucket.file(FILE_PATH);

  const [metadata] = await file.getMetadata();
  const currentUpdatedAt = metadata.updated;

  if (data._version && data._version !== currentUpdatedAt) {
    throw new HttpsError(
      "aborted",
      "Data has been modified by another admin. Please download again."
    );
  }

  // 🔥 Backup before overwrite
  const backupFile = bucket.file(
    `data-web/backups/data_backup_${Date.now()}.json`
  );

  const [contents] = await file.download();
  await backupFile.save(contents, {
    contentType: "application/json",
  });

  // 🔥 Save new data
  await file.save(
    JSON.stringify(data, null, 2),
    { contentType: "application/json; charset=utf-8" }
  );

  // 🔥 IMPORTANT: get new metadata after save
  const [newMetadata] = await file.getMetadata();

  return {
    success: true,
    version: newMetadata.updated,
  };
});