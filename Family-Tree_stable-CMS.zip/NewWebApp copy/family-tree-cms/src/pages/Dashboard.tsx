import { useEffect, useState, useMemo, useRef } from "react";
import { httpsCallable } from "firebase/functions";
import { functions, auth } from "../firebase/firebase";
import { signOut } from "firebase/auth";
import { db } from "../db/database";
import { uploadData } from "../services/storageService";
import { createRelations, updateMarriageDate, deleteAllRelationsOfMember } from "../services/relationService";
import { propagateGotra, deleteMember } from "../services/memberService";
import { getSiblings, getChildren, getSpouseMember, getGrandParents, getGrandChildren } from "../services/lineageService";
import { dedupeMembers, dedupeRelations } from "../services/dedupeService";

import Button from "../components/Button";
import Input from "../components/Input";
import PanelLayout from "../components/PanelLayout";
import Section from "../components/Section";
import AddMemberModal from "../components/AddMemberModal";
import ConfirmModal from "../components/ConfirmModal";
import Toast from "../components/Toast";
import AddRelationModal from "../components/AddRelationModal";
import EditMarriageModal from "../components/EditMarriageModal";
import { INDIA_STATES } from "../constants/states";
import type { FamilyMember,FamilyRelation } from "../types/family";
import { getGotraHindi, formatGotra } from "../utils/laungageUtil";

export default function Dashboard() {
  /* ===============================
     STATE
  =============================== */
  const [members, setMembers] = useState<any[]>([]);
  const [relations, setRelations] = useState<any[]>([]);
  const [selectedMember, setSelectedMember] = useState<any | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showDeleteRelationsConfirm, setShowDeleteRelationsConfirm] = useState(false);
  const [showEditMarriageModal, setShowEditMarriageModal] = useState(false);
  const [showGotraDropdown, setShowGotraDropdown] = useState(false);
  const [highlightIndex, setHighlightIndex] = useState(0);
  const [showMemberModal, setShowMemberModal] = useState(false);
  const [showRelationModal, setShowRelationModal] = useState(false);
  const [showDownloadConfirm, setShowDownloadConfirm] = useState(false);

  const [search, setSearch] = useState("");
  const hasDirty = useMemo(() =>
    members.some(m => m._isDirty || m.isNewEntry) ||
    relations.some(r => r._isDirty || r.isNewEntry),
  [members, relations]);
  
  const [version, setVersion] = useState<string | null>(null);

  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);
  

  const downloadFn = httpsCallable(functions, "downloadFamilyData");
  const uploadFn = httpsCallable(functions, "uploadFamilyData");


  const gotraRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        gotraRef.current &&
        !gotraRef.current.contains(event.target as Node)
      ) {
        setShowGotraDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener(
        "mousedown",
        handleClickOutside
      );
  }, []);

  const parents = useMemo(() => {
    if (!selectedMember) return [];
  
    return relations
      .filter(
        (r) =>
          r.relatedMemberId === selectedMember.memberId &&
          (r.relationType === "Father" ||
           r.relationType === "Mother")
      )
      .map((r) =>
        members.find((m) =>
          m.memberId === r.relatesToMemberId
        )
      )
      .filter(Boolean);
  }, [selectedMember, relations, members]);
   /* ===============================
          FETCH RELATIVES
  =============================== */
  const spouse = useMemo(() => {
    return selectedMember
      ? getSpouseMember(
          selectedMember.memberId,
          members,
          relations
        )
      : null;
  }, [selectedMember, members, relations]);
  
  const children = useMemo(() => {
    if (!selectedMember) return [];
  
    return getChildren(
      selectedMember.memberId,
      members,
      relations
    );
  }, [selectedMember, members, relations]);
  
  const siblings = useMemo(() => {
    if (!selectedMember) return [];
  
    return getSiblings(
      selectedMember.memberId,
      members,
      relations
    );
  }, [selectedMember, members, relations]);

  const grandParents = useMemo(() => {
    if (!selectedMember) return { paternal: [], maternal: [] };
    return getGrandParents(
      selectedMember.memberId,
      members,
      relations
    );
  }, [selectedMember, members, relations]);
  
  const grandChildren = useMemo(() => {
    if (!selectedMember) return { sonsChildren: [], daughtersChildren: [] };
    return getGrandChildren(
      selectedMember.memberId,
      members,
      relations
    );
  }, [selectedMember, members, relations]);
  /* ===============================
     LOCAL CACHE
  =============================== */

  useEffect(() => {
    db.members.bulkPut(members);
  }, [members]);
  
  useEffect(() => {
    db.relations.bulkPut(relations);
  }, [relations]);

  useEffect(() => {
    const loadLocal = async () => {
      const localMembers = await db.members.toArray();
      const localRelations = await db.relations.toArray();

      if (localMembers.length > 0) {
        setMembers(localMembers);
        setRelations(localRelations);
      }
    };

    loadLocal();
  }, []);

  /* ===============================
     DOWNLOAD / UPLOAD
  =============================== */

  const handleDownload = async () => {
    try {
      const result: any = await downloadFn();
      const data = result.data;
  
      const cleanedMembers = dedupeMembers(
        members.map(m => ({
          ...m,
          _isDirty: false,
          isNewEntry: false
        }))
      );
      
      const cleanedRelations = dedupeRelations(
        relations.map(r => ({
          ...r,
          _isDirty: false,
          isNewEntry: false
        }))
      );
  
      await db.transaction("rw", db.members, db.relations, async () => {
        await db.members.clear();
        await db.relations.clear();
        await db.members.bulkAdd(cleanedMembers);
        await db.relations.bulkAdd(cleanedRelations);
      });
  
      setMembers(cleanedMembers);
      setRelations(cleanedRelations);
      setVersion(data._version);
  
      setToast({
        message: "Data refreshed successfully",
        type: "success",
      });
    } catch {
      setToast({ message: "Download failed", type: "error" });
    }
  };
  const handleUpload = async () => {

    const hasDirty =
      members.some(m => m._isDirty) ||
      relations.some(r => r._isDirty);
  
    if (!hasDirty) {
      setToast({ message: "No changes to upload", type: "error" });
      return;
    }
  
    try {
  
      /* ===============================
         CLEAN DUPLICATES BEFORE UPLOAD
      =============================== */
  
      const cleanedMembersRaw = dedupeMembers(members);
      const cleanedRelationsRaw = dedupeRelations(relations);
  
      /* ===============================
         UPLOAD CLEAN DATA
      =============================== */
  
      const result = await uploadData(
        uploadFn,
        cleanedMembersRaw,
        cleanedRelationsRaw,
        version
      );
  
      setVersion(result.data.version);
  
      /* ===============================
         RESET DIRTY FLAGS
      =============================== */
  
      const cleanedMembers = cleanedMembersRaw.map(m => ({
        ...m,
        _isDirty: false,
        isNewEntry: false
      }));
  
      const cleanedRelations = cleanedRelationsRaw.map(r => ({
        ...r,
        _isDirty: false,
        isNewEntry: false
      }));
  
      setMembers(cleanedMembers);
      setRelations(cleanedRelations);
  
      await db.transaction("rw", db.members, db.relations, async () => {
        await db.members.bulkPut(cleanedMembers);
        await db.relations.bulkPut(cleanedRelations);
      });
  
      setToast({
        message: "Upload successful (duplicates cleaned)",
        type: "success"
      });
  
    } catch (e: any) {
      setToast({ message: e.message, type: "error" });
    }
  };

  /* ===============================
     MEMBER LOGIC
  =============================== */

  const uniqueGotras = useMemo(() => {
    const gotraSet = new Set<string>();
  
    members.forEach((m) => {
      if (m.gotra?.trim()) {
        gotraSet.add(m.gotra.trim());
      }
    });
  
    return Array.from(gotraSet).sort();
  }, [members]);

  const filteredGotras = useMemo(() => {
    if (!selectedMember?.gotra) return [];
  
    return uniqueGotras.filter((g) =>
      g.toLowerCase().includes(
        selectedMember.gotra.toLowerCase()
      )
    );
  }, [selectedMember?.gotra, uniqueGotras]);

  const handleAddMember = (formData: any) => {
    const newId =
      Math.max(...members.map((m) => m.memberId), 0) + 1;
  
    const currentUserEmail =
      auth.currentUser?.email ?? "unknown";
  
    const newMember = {
      memberId: newId,
      fullName: formData.fullName,
      dob: formData.dob,
      dod: formData.dod ?? "",
      gender: formData.gender,
      gotra: formData.gotra,
      isLiving: formData.isLiving,
      isNewEntry: false,
      city: formData.city,
      state: formData.state,
      mobile: formData.mobile ?? "",
      updatedAt: Date.now().toString(),
      updatedBy: currentUserEmail,
      _isDirty: true,
    };
  
    // Add to list
    const updatedMembers = [...members, newMember];
  
    setMembers(updatedMembers);
    setSelectedMember(newMember);     // 🔥 Select new member
  
    setShowMemberModal(false);
  
    // 🔥 Automatically open relation modal
    if (updatedMembers.length > 1) {
      setShowRelationModal(true);
    }
  };

  const updateMemberField = (field: string, value: any) => {
    if (!selectedMember) return;

    const now = Date.now().toString();
    const email = auth.currentUser?.email ?? "unknown";

    const oldGotra = selectedMember.gotra;

    let updatedMember = {
      ...selectedMember,
      [field]: value,
      updatedAt: now,
      updatedBy: email,
      _isDirty: true,
    };

    let updatedMembers = members.map((m) =>
      m.memberId === updatedMember.memberId ? updatedMember : m
    );

    if (field === "gotra" && updatedMember.gender === "M" && value !== oldGotra) {
      updatedMembers = propagateGotra(
        updatedMember.memberId,
        value,
        updatedMembers,
        relations,
        email
      );
    }

    setMembers(updatedMembers);
    setSelectedMember(updatedMember);
  };

  const handleDeleteMember = () => {
    if (!selectedMember) return;
  
    const { updatedMembers, updatedRelations } =
      deleteMember(
        selectedMember.memberId,
        members,
        relations
      );
  
    setMembers(updatedMembers);
    setRelations(updatedRelations);
  
    setSelectedMember(null);
    setShowDeleteConfirm(false);
  
    setToast({
      message: "Member and related relations deleted",
      type: "success",
    });
  };

  /* ===============================
     RELATION LOGIC
  =============================== */

  const handleAddRelation = (
    secondMember: FamilyMember,
    relationType: FamilyRelation["relationType"],
    dom?: string
  ) => {
  
    if (!selectedMember) return;
  
    const result = createRelations(
      selectedMember,
      secondMember,
      relationType,
      relations,
      members, // ← important (for validation)
      auth.currentUser?.email ?? "",
      dom
    );
  
    /* ===============================
       VALIDATION FAILURE
    =============================== */
  
    if (!result.success) {
      setToast({
        message: result.error || "Relation could not be created.",
        type: "error",
      });
      return;
    }
  
    const newRelations = result.relations ?? [];
  
    if (newRelations.length === 0) {
      setToast({
        message: "Relation already exists.",
        type: "error",
      });
      return;
    }
  
    /* ===============================
       MARK AFFECTED MEMBERS DIRTY
    =============================== */
  
    const affectedMemberIds = new Set<number>();
  
    newRelations.forEach((r) => {
      affectedMemberIds.add(r.relatedMemberId);
      affectedMemberIds.add(r.relatesToMemberId);
    });
  
    const updatedMembers = members.map((m) =>
      affectedMemberIds.has(m.memberId)
        ? {
            ...m,
            updatedAt: Date.now().toString(),
            updatedBy: auth.currentUser?.email ?? "",
            _isDirty: true,
          }
        : m
    );
  
    /* ===============================
       GOTRA PROPAGATION (HUSBAND CASE)
    =============================== */
  
    newRelations.forEach((rel) => {
      if (rel.relationType === "Husband") {
  
        const female = updatedMembers.find(
          (m) => m.memberId === rel.relatedMemberId
        );
  
        const husband = updatedMembers.find(
          (m) => m.memberId === rel.relatesToMemberId
        );
  
        if (female && husband && husband.gotra) {
          female.gotra = husband.gotra;
          female.updatedAt = Date.now().toString();
          female.updatedBy = auth.currentUser?.email ?? "";
          female._isDirty = true;
        }
      }
    });
  
    /* ===============================
       APPLY STATE
    =============================== */
  
    setMembers(updatedMembers);
    setRelations((prev) => [...prev, ...newRelations]);
  
    setShowRelationModal(false);
  
    setToast({
      message: "Relations added successfully",
      type: "success",
    });
  };

   /* ===============================
       DELETE ALL RELATIONS FOR A MEMBER
    =============================== */

    const handleDeleteAllRelations = () => {

      if (!selectedMember) return;
    
      const { updatedRelations, affectedMemberIds } =
        deleteAllRelationsOfMember(
          selectedMember.memberId,
          relations,
          auth.currentUser?.email ?? ""
        );
    
      // Mark affected members dirty
      const updatedMembers = members.map(m =>
        affectedMemberIds.includes(m.memberId)
          ? {
              ...m,
              updatedAt: Date.now().toString(),
              updatedBy: auth.currentUser?.email ?? "",
              _isDirty: true
            }
          : m
      );
    
      setRelations(updatedRelations);
      setMembers(updatedMembers);
      setShowDeleteRelationsConfirm(false);
    
      setToast({
        message: "All relations removed successfully",
        type: "success"
      });
    };


  /* ===============================
     FILTER
  =============================== */

  const filteredMembers = useMemo(() => {
    if (!search.trim()) return members;
  
    const tokens = search
      .toLowerCase()
      .trim()
      .split(/\s+/); // split by space
  
    return members.filter((m) => {
  
      const searchableString = `
        ${m.fullName}
        ${m.city}
        ${m.state}
        ${m.gotra}
      `
        .toLowerCase();
  
      // Every token must exist somewhere
      return tokens.every(token =>
        searchableString.includes(token)
      );
    });
  
  }, [members, search]);

  /* ===============================
     UI
  =============================== */

  return (
    <>
      {/* TOP NAV */}
      <div className="top-nav">
        <div className="top-nav-title">
          Family Tree CMS {hasDirty && "• Unsaved"}
        </div>

        <div className="top-nav-actions">
          <Button
            onClick={() => (hasDirty ? setShowDownloadConfirm(true) : handleDownload())}
          >
            Download
          </Button>
          <Button onClick={handleUpload}>Upload</Button>
          <Button onClick={() => setShowMemberModal(true)}>Add Member</Button>
          <Button onClick={() => signOut(auth)}>Logout</Button>
        </div>
      </div>

      <div className="page-content">
        <PanelLayout
          left={
            <>
              <Input value={search} onChange={setSearch} placeholder="Search member..." />
              <hr />
              <div>
                {filteredMembers.map((m) => (
                  <div
                    key={m.memberId}
                    className={`member-item ${
                      selectedMember?.memberId === m.memberId ? "active" : ""
                    } ${m._isDirty ? "member-dirty" : ""}`}
                    onClick={() => setSelectedMember(m)}
                  >
                    <strong>{m.fullName} - {m.memberId}</strong>
                    <div style={{ fontSize: 12 }}>
                      {m.city}, {m.state}
                    </div>
                  </div>
                ))}
              </div>
            </>
          }
          right={
            selectedMember ? (
              <>
                <Section title="Member Details">
                  <div className="member-details">

                    {/* Full Name */}
                    <input
                      className="input-field"
                      value={selectedMember.fullName}
                      onChange={(e) =>
                        updateMemberField("fullName", e.target.value)
                      }
                      placeholder="Full Name"
                    />

                    {/* Gotra */}
                    <div ref={gotraRef} style={{ position: "relative", width: "80%" }}>
                      <input
                        className="input-field"
                        value={selectedMember.gotra}
                        placeholder="Search or enter gotra"
                        onFocus={() => setShowGotraDropdown(true)}
                        onChange={(e) => {
                          const formatted = formatGotra(e.target.value);
                          updateMemberField("gotra", formatted);
                          setShowGotraDropdown(true);
                          setHighlightIndex(0);
                        }}
                        onKeyDown={(e) => {
                          if (!showGotraDropdown) return;

                          if (e.key === "ArrowDown") {
                            e.preventDefault();
                            setHighlightIndex((prev) =>
                              prev < filteredGotras.length - 1 ? prev + 1 : prev
                            );
                          }

                          if (e.key === "ArrowUp") {
                            e.preventDefault();
                            setHighlightIndex((prev) =>
                              prev > 0 ? prev - 1 : 0
                            );
                          }

                          if (e.key === "Enter") {
                            e.preventDefault();

                            if (filteredGotras[highlightIndex]) {
                              updateMemberField(
                                "gotra",
                                filteredGotras[highlightIndex]
                              );
                            }

                            setShowGotraDropdown(false);
                          }

                          if (e.key === "Escape") {
                            setShowGotraDropdown(false);
                          }
                        }}
                      />

                      {showGotraDropdown &&
                        selectedMember.gotra && (
                          <div className="dropdown-list">

                            {filteredGotras.map((g, index) => {
                              const hindi = getGotraHindi(g);

                              return (
                                <div
                                  key={g}
                                  className={`dropdown-item ${
                                    index === highlightIndex ? "active-item" : ""
                                  }`}
                                  onMouseEnter={() =>
                                    setHighlightIndex(index)
                                  }
                                  onClick={() => {
                                    updateMemberField("gotra", g);
                                    setShowGotraDropdown(false);
                                  }}
                                >
                                  {g}
                                  {hindi && (
                                    <span
                                      style={{
                                        opacity: 0.6,
                                        marginLeft: 8,
                                      }}
                                    >
                                      - {hindi}
                                    </span>
                                  )}
                                </div>
                              );
                            })}

                            {!uniqueGotras.some(
                              (g) =>
                                g.toLowerCase() ===
                                selectedMember.gotra.toLowerCase()
                            ) && (
                              <div
                                className="dropdown-item"
                                style={{
                                  fontStyle: "italic",
                                  opacity: 0.7,
                                }}
                              >
                                Create "{selectedMember.gotra}"
                              </div>
                            )}

                          </div>
                        )}
                    </div>

                    {/* Gender */}
                    <select
                      className="input-field"
                      value={selectedMember.gender}
                      onChange={(e) =>
                        updateMemberField("gender", e.target.value)
                      }
                    >
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                    </select>

                    {/* Date of Birth */}
                    <input
                      type="date"
                      className="input-field"
                      value={selectedMember.dob}
                      max={new Date().toISOString().split("T")[0]}
                      onChange={(e) =>
                        updateMemberField("dob", e.target.value)
                      }
                    />

                    {/* Living */}
                    <label style={{ marginTop: 10 }}>
                      <input
                        type="checkbox"
                        checked={selectedMember.isLiving}
                        onChange={(e) =>
                          updateMemberField("isLiving", e.target.checked)
                        }
                      />
                      &nbsp;Living
                    </label>

                    {/* Date of Death */}
                    {!selectedMember.isLiving && (
                      <input
                        type="date"
                        className="input-field"
                        value={selectedMember.dod}
                        max={new Date().toISOString().split("T")[0]}
                        onChange={(e) =>
                          updateMemberField("dod", e.target.value)
                        }
                      />
                    )}

                    {/* City */}
                    <input
                      className="input-field"
                      value={selectedMember.city}
                      onChange={(e) =>
                        updateMemberField("city", e.target.value)
                      }
                      placeholder="City"
                    />

                    {/* State */}
                    <select
                      className="input-field"
                      value={selectedMember.state}
                      onChange={(e) =>
                        updateMemberField("state", e.target.value)
                      }
                    >
                      {INDIA_STATES.map((state) => (
                        <option key={state} value={state}>
                          {state}
                        </option>
                      ))}
                    </select>

                    {/* Mobile */}
                    <input
                      className="input-field"
                      value={selectedMember.mobile}
                      maxLength={10}
                      onChange={(e) =>
                        updateMemberField(
                          "mobile",
                          e.target.value.replace(/\D/g, "")
                        )
                      }
                      placeholder="Mobile"
                    />

                  </div>
                </Section>

                <Section title="Relations">
                  <div className="button-group">
                    <Button
                      variant="danger"
                      onClick={() => setShowDeleteConfirm(true)}
                    >
                      Delete Member
                    </Button>

                    <Button onClick={() => setShowRelationModal(true)}>
                      Add Relation
                    </Button>

                    <Button
                      variant="danger"
                      onClick={() => setShowDeleteRelationsConfirm(true)}
                    >
                      Delete All Relations
                    </Button>
                  </div>

                   {/* Parents */}
                    {parents.length > 0 && (
                      <div>
                        <strong>Parents:</strong>
                        {parents.map((p) => {
                          const type =
                            p.gender === "M" ? "Father" : "Mother";
                          return (
                            <div key={p.memberId}>
                            {type}: {p.fullName}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Spouse */}
                    {spouse && selectedMember && (
                      <div style={{ marginTop: 10 }}>
                        <strong>Spouse:</strong>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <span>
                            {selectedMember.gender === "M"
                              ? "Wife"
                              : "Husband"}: {spouse.fullName}
                          </span>

                          <Button
                            variant="secondary"
                            onClick={() => {
                              setShowEditMarriageModal(true);
                            }}
                          >
                            ✏ Edit DOM
                          </Button>
                        </div>
                      </div>
                    )}

                    {/* Children */}
                    {children.length > 0 && (
                      <div style={{ marginTop: 10 }}>
                        <strong>Children:</strong>

                        {children.map(child => {

                          const spouse = getSpouseMember(
                            child.memberId,
                            members,
                            relations
                          );

                          const relationWord =
                            child.gender === "M" ? "Son (Beta)" : "Daughter (Beti)";

                          return (
                            <div key={child.memberId} style={{ marginTop: 6 }}>
                              <div>
                                {relationWord}: {child.fullName}
                              </div>

                              {spouse && (
                                <div style={{ marginLeft: 20 }}>
                                  {child.gender === "M"
                                    ? `Bahu (Son's Wife): ${spouse.fullName}`
                                    : `Damad (Daughter's Husband): ${spouse.fullName}`}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Siblings */}
                    {siblings.length > 0 && (
                      <div style={{ marginTop: 10 }}>
                        <strong>Siblings:</strong>
                        {siblings.map((s) => {
                          const relationWord =
                            s.gender === "M" ? "Brother" : "Sister";
                          return (
                            <div key={s.memberId}>
                              {relationWord}: {s.fullName}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* GrandParents Father side*/}
                    {grandParents.paternal.length > 0 && (
                      <div style={{ marginTop: 10 }}>
                        <strong>Paternal Grandparents:</strong>
                        {grandParents.paternal.map(gp => (
                          <div key={gp.memberId}>
                            {gp.gender === "M" ? "Grandfather (Dada)" : "Grandmother (Dadi)"}: {gp.fullName}
                          </div>
                        ))}
                      </div>
                    )}
                    {/* GrandParents Mother side*/}
                    {grandParents.maternal.length > 0 && (
                      <div style={{ marginTop: 10 }}>
                        <strong>Maternal Grandparents:</strong>
                        {grandParents.maternal.map(gp => (
                          <div key={gp.memberId}>
                            {gp.gender === "M" ? "Grandfather (Nana)" : "Grandmother (Nani)"}: {gp.fullName}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Grand Children */}
                    {(grandChildren.sonsChildren.length > 0 ||
                      grandChildren.daughtersChildren.length > 0) && (

                      <div style={{ marginTop: 15 }}>
                        <strong>Grand Children:</strong>

                        {/* Son's Children */}
                        {grandChildren.sonsChildren.map(gc => {

                          const spouse = getSpouseMember(
                            gc.memberId,
                            members,
                            relations
                          );

                          return (
                            <div key={gc.memberId} style={{ marginTop: 6 }}>
                              <div>
                                {gc.gender === "M"
                                  ? "Pota (Grandson)"
                                  : "Poti (Granddaughter)"}: {gc.fullName}
                              </div>

                              {spouse && (
                                <div style={{ marginLeft: 20 }}>
                                  {gc.gender === "M"
                                    ? `Pota Bahu: ${spouse.fullName}`
                                    : `Poti Damad: ${spouse.fullName}`}
                                </div>
                              )}
                            </div>
                          );
                        })}

                        {/* Daughter's Children */}
                        {grandChildren.daughtersChildren.map(gc => {

                          const spouse = getSpouseMember(
                            gc.memberId,
                            members,
                            relations
                          );

                          return (
                            <div key={gc.memberId} style={{ marginTop: 6 }}>
                              <div>
                                {gc.gender === "M"
                                  ? "Nata (Daughter's Son)"
                                  : "Nati (Daughter's Daughter)"}: {gc.fullName}
                              </div>

                              {spouse && (
                                <div style={{ marginLeft: 20 }}>
                                  {gc.gender === "M"
                                    ? `Nata Bahu: ${spouse.fullName}`
                                    : `Nati Damad: ${spouse.fullName}`}
                                </div>
                              )}
                            </div>
                          );
                        })}

                      </div>
                    )}
                </Section>
              </>
            ) : (
              <p>Select a member to view details</p>
            )
          }
        />
      </div>

      {showMemberModal && (
        <AddMemberModal
          gotras={uniqueGotras}
          onClose={() => setShowMemberModal(false)}
          onSave={handleAddMember}
        />
      )}

      {showRelationModal && selectedMember && (
        <AddRelationModal
          selectedMember={selectedMember}
          allMembers={members}
          relations={relations}
          currentUserEmail={auth.currentUser?.email || ""}
          onClose={() => setShowRelationModal(false)}
          onSave={handleAddRelation}
        />
      )}

      {showDownloadConfirm && (
        <ConfirmModal
          title="Unsynced Changes"
          message="Refreshing will discard local changes. Continue?"
          confirmText="Discard & Refresh"
          cancelText="Cancel"
          danger
          onCancel={() => setShowDownloadConfirm(false)}
          onConfirm={() => {
            setShowDownloadConfirm(false);
            handleDownload();
          }}
        />
      )}

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
      {showDeleteConfirm && selectedMember && (
        <ConfirmModal
          title="Delete Member"
          message={`Are you sure you want to delete ${selectedMember.fullName}? This will remove all related relations permanently.`}
          confirmText="Delete"
          cancelText="Cancel"
          danger
          onCancel={() => setShowDeleteConfirm(false)}
          onConfirm={handleDeleteMember}
        />
      )}
      {showEditMarriageModal && spouse && selectedMember && (
        <EditMarriageModal
          memberId={selectedMember.memberId}
          spouseId={spouse.memberId}
          relations={relations}
          onClose={() => setShowEditMarriageModal(false)}
          onSave={(newDom) => {
            const updatedRelations = updateMarriageDate(
              selectedMember.memberId,
              spouse.memberId,
              newDom,
              relations,
              auth.currentUser?.email ?? ""
            );

            setRelations(updatedRelations);
            setShowEditMarriageModal(false);

            setToast({
              message: "Marriage date updated",
              type: "success",
            });
          }}
        />
      )}
      {showDeleteRelationsConfirm && selectedMember && (
        <ConfirmModal
          title="Delete All Relations"
          message={`Are you sure you want to delete ALL relations of ${selectedMember.fullName}?`}
          confirmText="Delete All"
          cancelText="Cancel"
          danger
          onCancel={() => setShowDeleteRelationsConfirm(false)}
          onConfirm={handleDeleteAllRelations}
        />
      )}
    </>
  );
}