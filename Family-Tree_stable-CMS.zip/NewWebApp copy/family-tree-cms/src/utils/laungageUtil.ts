
// Hardcoded mapping (can later move to JSON)
const GOTRA_HINDI_MAP: Record<string, string> = {
    khedavdiya: "खेडावड़िया",
    vishwakarma: "विश्वकर्मा",
    sharma: "शर्मा",
  };
  
  // Normalize key
  const normalize = (text: string) =>
    text.trim().toLowerCase();
  
  // Public function
  export const getGotraHindi = (gotra: string): string | null => {
    const key = normalize(gotra);
    return GOTRA_HINDI_MAP[key] ?? null;
  };
  
  // Auto capitalize properly (Title Case)
  export const formatGotra = (value: string): string => {
    if (!value) return "";
  
    return value
      .toLowerCase()
      .split(" ")
      .map(word =>
        word.charAt(0).toUpperCase() + word.slice(1)
      )
      .join(" ");
  };