import type {
  FamilyMember,
  FamilyRelation,
} from "../types/family";
import {
  getChildren,
  getSpouse,
} from "./lineageService";


export const deleteMember = (
  memberId: number,
  members: FamilyMember[],
  relations: FamilyRelation[]
) => {
  const updatedMembers = members.filter(
    (m) => m.memberId !== memberId
  );

  const updatedRelations = relations.filter(
    (r) =>
      r.relatedMemberId !== memberId &&
      r.relatesToMemberId !== memberId
  );

  return {
    updatedMembers,
    updatedRelations,
  };
};

export const propagateGotra = (
  rootMaleId: number,
  newGotra: string,
  members: FamilyMember[],
  relations: FamilyRelation[],
  currentUserEmail: string
): FamilyMember[] => {
  const visited = new Set<number>();
  const updatedMembers = [...members];
  const now = Date.now().toString();

  const dfs = (maleId: number) => {
    if (visited.has(maleId)) return;
    visited.add(maleId);

    const male = updatedMembers.find(
      (m) => m.memberId === maleId
    );
    if (!male) return;

    male.gotra = newGotra;
    male.updatedAt = now;
    male.updatedBy = currentUserEmail;
    male._isDirty = true;

    const spouseId = getSpouse(maleId, relations);

    if (spouseId) {
      const spouse = updatedMembers.find(
        (m) => m.memberId === spouseId
      );
      if (spouse) {
        spouse.gotra = newGotra;
        spouse.updatedAt = now;
        spouse.updatedBy = currentUserEmail;
        spouse._isDirty = true;
      }
    }

    const children = getChildren(maleId, members, relations);

    children.forEach((childId) => {
      const child = updatedMembers.find(
        (m) => m.memberId === childId.memberId
      );
      if (!child) return;

      if (child.gender === "M") {
        dfs(child.memberId);
      } else {
        const married =
          getSpouse(child.memberId, relations) !== null;

        if (!married) {
          child.gotra = newGotra;
          child.updatedAt = now;
          child.updatedBy = currentUserEmail;
          child._isDirty = true;
        }
      }
    });
  };

  dfs(rootMaleId);

  return updatedMembers;
};