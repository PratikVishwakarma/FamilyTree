import type { FamilyMember, FamilyRelation } from "../types/family";

/* ===================================
     GET THE SPOUSE ID ONLY
  ==================================== */
export const getSpouse = (
    memberId: number,
    relations: FamilyRelation[]
  ): number | null => {
  
    const relation = relations.find(
      (r) =>
        r.relatedMemberId === memberId &&
        (r.relationType === "Wife" ||
         r.relationType === "Husband")
    );
  
    return relation ? relation.relatesToMemberId : null;
  };
  
  /* ===================================
     GET THE SPOUSE
  ==================================== */
  export const getSpouseMember = (
    memberId: number,
    members: FamilyMember[],
    relations: FamilyRelation[]
  ): FamilyMember | null => {
  
    const relation = relations.find(
      (r) =>
        (r.relatedMemberId === memberId ||
         r.relatesToMemberId === memberId) &&
        (r.relationType === "Wife" ||
         r.relationType === "Husband")
    );
  
    if (!relation) return null;
  
    const spouseId =
      relation.relatedMemberId === memberId
        ? relation.relatesToMemberId
        : relation.relatedMemberId;
  
    return members.find(m => m.memberId === spouseId) || null;
  };


export const getSiblings = (
    memberId: number,
    members: FamilyMember[],
    relations: FamilyRelation[]
  ): FamilyMember[] => {
    // Step 1: Find parents of selected member
    const parentIds = relations
      .filter(
        (r) =>
          r.relatedMemberId === memberId &&
          (r.relationType === "Father" ||
            r.relationType === "Mother")
      )
      .map((r) => r.relatesToMemberId);
  
    if (parentIds.length === 0) return [];
  
    // Step 2: Find other children of those parents
    const siblingIds = relations
      .filter(
        (r) =>
          parentIds.includes(r.relatesToMemberId) &&
          (r.relationType === "Father" ||
            r.relationType === "Mother")
      )
      .map((r) => r.relatedMemberId)
      .filter((id) => id !== memberId); // exclude self
  
    // Remove duplicates
    const uniqueSiblingIds = [...new Set(siblingIds)];
  
    return members.filter((m) =>
      uniqueSiblingIds.includes(m.memberId)
    );
  };


  export const getChildren = (
    memberId: number,
    members: FamilyMember[],
    relations: FamilyRelation[]
  ): FamilyMember[] => {
  
    const childIds = relations
      .filter(
        (r) =>
          r.relatesToMemberId === memberId &&
          (r.relationType === "Father" ||
           r.relationType === "Mother")
      )
      .map((r) => r.relatedMemberId);
  
    const uniqueIds = [...new Set(childIds)];
  
    return members.filter((m) =>
      uniqueIds.includes(m.memberId)
    );
  };


/* ===================================
     GET THE GRANDPARENTS BOTH SIDE
  ==================================== */


  export const getGrandParents = (
    memberId: number,
    members: FamilyMember[],
    relations: FamilyRelation[]
  ): {
    paternal: FamilyMember[];
    maternal: FamilyMember[];
  } => {
  
    const parents = relations
      .filter(
        r =>
          r.relatedMemberId === memberId &&
          (r.relationType === "Father" ||
           r.relationType === "Mother")
      )
      .map(r => ({
        id: r.relatesToMemberId,
        type: r.relationType
      }));
  
    const paternal: FamilyMember[] = [];
    const maternal: FamilyMember[] = [];
  
    parents.forEach(parent => {
  
      const grandParents = relations
        .filter(
          r =>
            r.relatedMemberId === parent.id &&
            (r.relationType === "Father" ||
             r.relationType === "Mother")
        )
        .map(r => r.relatesToMemberId);
  
      const gpMembers = members.filter(m =>
        grandParents.includes(m.memberId)
      );
  
      if (parent.type === "Father") {
        paternal.push(...gpMembers);
      }
  
      if (parent.type === "Mother") {
        maternal.push(...gpMembers);
      }
    });
  
    return { paternal, maternal };
  };


  /* ====================
     GET THE GARNDCHILDS
  ======================= */

  export const getGrandChildren = (
    memberId: number,
    members: FamilyMember[],
    relations: FamilyRelation[]
  ): {
    sonsChildren: FamilyMember[];
    daughtersChildren: FamilyMember[];
  } => {
  
    const children = relations
      .filter(
        r =>
          r.relatesToMemberId === memberId &&
          (r.relationType === "Father" ||
           r.relationType === "Mother")
      )
      .map(r => r.relatedMemberId);
  
    const sonsChildren: FamilyMember[] = [];
    const daughtersChildren: FamilyMember[] = [];
  
    children.forEach(childId => {
  
      const child = members.find(m => m.memberId === childId);
      if (!child) return;
  
      const grandChildren = relations
        .filter(
          r =>
            r.relatesToMemberId === childId &&
            (r.relationType === "Father" ||
             r.relationType === "Mother")
        )
        .map(r => r.relatedMemberId);
  
      const gcMembers = members.filter(m =>
        grandChildren.includes(m.memberId)
      );
  
      if (child.gender === "M") {
        sonsChildren.push(...gcMembers);
      }
  
      if (child.gender === "F") {
        daughtersChildren.push(...gcMembers);
      }
    });
  
    return { sonsChildren, daughtersChildren };
  };


  /* ===================================
     GET THE
  ==================================== */