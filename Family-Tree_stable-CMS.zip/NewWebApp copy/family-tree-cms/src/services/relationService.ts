import type { FamilyMember, FamilyRelation } from "../types/family";

export const createRelations = (
  selectedMember: FamilyMember,
  secondMember: FamilyMember,
  relationType: FamilyRelation["relationType"],
  relations: FamilyRelation[],
  members: FamilyMember[],
  currentUserEmail: string,
  dom?: string
): {
  success: boolean;
  relations?: FamilyRelation[];
  error?: string;
} => {

  const now = Date.now().toString();
  const newRelations: FamilyRelation[] = [];

  /* =========================================================
     HELPERS
  ========================================================= */

  const relationExists = (
    relatedId: number,
    relatesToId: number,
    type: FamilyRelation["relationType"]
  ) =>
    relations.some(
      (r) =>
        r.relatedMemberId === relatedId &&
        r.relatesToMemberId === relatesToId &&
        r.relationType === type
    );

  const hasParent = (
    childId: number,
    type: "Father" | "Mother"
  ) =>
    relations.some(
      (r) =>
        r.relatedMemberId === childId &&
        r.relationType === type
    );

  const getParents = (memberId: number): number[] =>
    relations
      .filter(
        (r) =>
          r.relatedMemberId === memberId &&
          (r.relationType === "Father" ||
           r.relationType === "Mother")
      )
      .map((r) => r.relatesToMemberId);

  const getChildren = (memberId: number): number[] =>
    relations
      .filter(
        (r) =>
          (r.relationType === "Father" ||
           r.relationType === "Mother") &&
          r.relatesToMemberId === memberId
      )
      .map((r) => r.relatedMemberId);

  const hasActiveSpouse = (memberId: number) => {
    const member = members.find(m => m.memberId === memberId);
    if (!member?.isLiving) return false;

    return relations.some(
      (r) =>
        (r.relatedMemberId === memberId ||
         r.relatesToMemberId === memberId) &&
        (r.relationType === "Husband" ||
         r.relationType === "Wife")
    );
  };

  const getSpouseId = (memberId: number): number | null => {
    const spouseRel = relations.find(
      (r) =>
        (r.relatedMemberId === memberId ||
         r.relatesToMemberId === memberId) &&
        (r.relationType === "Husband" ||
         r.relationType === "Wife")
    );

    if (!spouseRel) return null;

    return spouseRel.relatedMemberId === memberId
      ? spouseRel.relatesToMemberId
      : spouseRel.relatedMemberId;
  };

  const isAncestor = (
    ancestorId: number,
    descendantId: number,
    visited = new Set<number>()
  ): boolean => {

    if (visited.has(descendantId)) return false;
    visited.add(descendantId);

    const parents = getParents(descendantId);

    if (parents.includes(ancestorId)) return true;

    return parents.some(parent =>
      isAncestor(ancestorId, parent, visited)
    );
  };

  /* =========================================================
     VALIDATION SECTION
  ========================================================= */

  // Prevent self marriage
  if (
    (relationType === "Husband" || relationType === "Wife") &&
    selectedMember.memberId === secondMember.memberId
  ) {
    return { success: false, error: "A member cannot marry themselves." };
  }

  // Prevent parent-child marriage
  if (relationType === "Husband" || relationType === "Wife") {

    const selectedParents = getParents(selectedMember.memberId);
    const selectedChildren = getChildren(selectedMember.memberId);

    if (
      selectedParents.includes(secondMember.memberId) ||
      selectedChildren.includes(secondMember.memberId)
    ) {
      return {
        success: false,
        error: "Marriage between parent and child is not allowed."
      };
    }
  }

  // Prevent sibling marriage
  if (relationType === "Husband" || relationType === "Wife") {

    const selectedParents = getParents(selectedMember.memberId);
    const secondParents = getParents(secondMember.memberId);

    const commonParent = selectedParents.some(p =>
      secondParents.includes(p)
    );

    if (commonParent) {
      return {
        success: false,
        error: "Marriage between siblings is not allowed."
      };
    }
  }

  // Prevent circular ancestry
  if (relationType === "Father" || relationType === "Mother") {

    if (isAncestor(selectedMember.memberId, secondMember.memberId)) {
      return {
        success: false,
        error: "This creates circular ancestry."
      };
    }
  }

  // Single parent rule
  if (relationType === "Father") {
    if (hasParent(selectedMember.memberId, "Father")) {
      return { success: false, error: "This member already has a father." };
    }
  }

  if (relationType === "Mother") {
    if (hasParent(selectedMember.memberId, "Mother")) {
      return { success: false, error: "This member already has a mother." };
    }
  }

  // Single active spouse rule
  if (relationType === "Husband" || relationType === "Wife") {
    if (
      hasActiveSpouse(selectedMember.memberId) ||
      hasActiveSpouse(secondMember.memberId)
    ) {
      return {
        success: false,
        error: "One of the members already has an active spouse."
      };
    }
  }

  /* =========================================================
     BASE RELATION
  ========================================================= */

  if (!relationExists(
      selectedMember.memberId,
      secondMember.memberId,
      relationType
  )) {
    newRelations.push({
      relatedMemberId: selectedMember.memberId,
      relatesToMemberId: secondMember.memberId,
      relationType,
      dom: dom ?? "",
      updatedAt: now,
      updatedBy: currentUserEmail,
      isNewEntry: true,
    });
  }

  /* =========================================================
     SPOUSE LOGIC
  ========================================================= */

  if (relationType === "Husband" || relationType === "Wife") {

    const reverseType =
      relationType === "Wife" ? "Husband" : "Wife";

    if (!relationExists(
        secondMember.memberId,
        selectedMember.memberId,
        reverseType
    )) {
      newRelations.push({
        relatedMemberId: secondMember.memberId,
        relatesToMemberId: selectedMember.memberId,
        relationType: reverseType,
        dom: dom ?? "",
        updatedAt: now,
        updatedBy: currentUserEmail,
        isNewEntry: false,
      });
    }

    // Propagate children
    const husband =
      relationType === "Husband"
        ? secondMember
        : selectedMember;

    const wife =
      relationType === "Husband"
        ? selectedMember
        : secondMember;

    const children = relations.filter(
      (r) =>
        r.relationType === "Father" &&
        r.relatesToMemberId === husband.memberId
    );

    children.forEach(childRel => {

      const childId = childRel.relatedMemberId;

      if (!hasParent(childId, "Mother")) {
        newRelations.push({
          relatedMemberId: childId,
          relatesToMemberId: wife.memberId,
          relationType: "Mother",
          dom: "",
          updatedAt: now,
          updatedBy: currentUserEmail,
          isNewEntry: false,
        });
      }
    });
  }

  /* =========================================================
     AUTO OTHER PARENT LOGIC
  ========================================================= */

  if (relationType === "Mother") {

    const spouseId = getSpouseId(secondMember.memberId);

    if (spouseId && !hasParent(selectedMember.memberId, "Father")) {
      newRelations.push({
        relatedMemberId: selectedMember.memberId,
        relatesToMemberId: spouseId,
        relationType: "Father",
        dom: "",
        updatedAt: now,
        updatedBy: currentUserEmail,
        isNewEntry: false,
      });
    }
  }

  if (relationType === "Father") {

    const spouseId = getSpouseId(secondMember.memberId);

    if (spouseId && !hasParent(selectedMember.memberId, "Mother")) {
      newRelations.push({
        relatedMemberId: selectedMember.memberId,
        relatesToMemberId: spouseId,
        relationType: "Mother",
        dom: "",
        updatedAt: now,
        updatedBy: currentUserEmail,
        isNewEntry: false,
      });
    }
  }

  return {
    success: true,
    relations: newRelations
  };
};

 /* =========================================================
     UPDATE MAFFIAGE DATA
  ========================================================= */

export const updateMarriageDate = (
  memberId: number,
  spouseId: number,
  newDom: string,
  relations: FamilyRelation[],
  currentUserEmail: string
): FamilyRelation[] => {

  const now = Date.now().toString();

  return relations.map((r) => {
    const isDirectSpouseRelation =
      (r.relatedMemberId === memberId &&
        r.relatesToMemberId === spouseId &&
        (r.relationType === "Wife" ||
         r.relationType === "Husband")) ||

      (r.relatedMemberId === spouseId &&
        r.relatesToMemberId === memberId &&
        (r.relationType === "Wife" ||
         r.relationType === "Husband"));

    if (isDirectSpouseRelation) {
      return {
        ...r,
        dom: newDom,
        updatedAt: now,
        updatedBy: currentUserEmail,
      };
    }

    return r;
  });
};


/* =========================================================
     DELETE ALL THE RELATIONS FOR A SINGLE MEMBER
  ========================================================= */

export const deleteAllRelationsOfMember = (
  memberId: number,
  relations: FamilyRelation[],
  currentUserEmail: string
): {
  updatedRelations: FamilyRelation[];
  affectedMemberIds: number[];
} => {

  const affectedMemberIds = new Set<number>();

  relations.forEach(r => {
    if (
      r.relatedMemberId === memberId ||
      r.relatesToMemberId === memberId
    ) {
      affectedMemberIds.add(r.relatedMemberId);
      affectedMemberIds.add(r.relatesToMemberId);
    }
  });

  const updatedRelations = relations.filter(
    r =>
      r.relatedMemberId !== memberId &&
      r.relatesToMemberId !== memberId
  );

  return {
    updatedRelations,
    affectedMemberIds: [...affectedMemberIds]
  };
};