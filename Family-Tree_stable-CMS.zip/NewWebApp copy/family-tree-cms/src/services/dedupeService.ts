export const dedupeMembers = (members: any[]) => {

  const map = new Map<number, any>();

  members.forEach(m => {

    const existing = map.get(m.memberId);

    if (!existing) {
      map.set(m.memberId, m);
      return;
    }

    if (
      Number(m.updatedAt || 0) >
      Number(existing.updatedAt || 0)
    ) {
      map.set(m.memberId, m);
    }
  });

  return Array.from(map.values());
};

export const dedupeRelations = (relations: any[]) => {

  const map = new Map<string, any>();

  relations.forEach(r => {

    const key = `${r.relatedMemberId}_${r.relatesToMemberId}_${r.relationType}`;

    const existing = map.get(key);

    if (!existing) {
      map.set(key, r);
      return;
    }

    // Keep latest updatedAt
    if (
      Number(r.updatedAt || 0) >
      Number(existing.updatedAt || 0)
    ) {
      map.set(key, r);
    }
  });

  return Array.from(map.values());
};