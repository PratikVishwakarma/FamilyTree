import type {
    FamilyMember,
    FamilyRelation,
  } from "../types/family";
  
  export const downloadData = async (downloadFn: any) => {
    const result = await downloadFn();
  
    return {
      members: result.data.familyTree_members as FamilyMember[],
      relations:
        result.data.familyTree_relations as FamilyRelation[],
      version: result.data._version,
    };
  };
  
  export const uploadData = async (
    uploadFn: any,
    members: FamilyMember[],
    relations: FamilyRelation[],
    version: string = ""
  ) => {
    return await uploadFn({
      familyTree_members: members.map(
        ({ _isDirty, ...rest }) => rest
      ),
      familyTree_relations: relations,
      _version: version,
    });
  };