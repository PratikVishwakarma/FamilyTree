export interface FamilyMember {
    memberId: number;
    fullName: string;
    gender: "M" | "F";
    gotra: string;
    dob: string;
    dod: string;
    isLiving: boolean;
    city: string;
    state: string;
    mobile: string;
    updatedAt: string;
    updatedBy: string;
    isNewEntry: boolean;
    _isDirty?: boolean;
  }
  
  export interface FamilyRelation {
    relatedMemberId: number;
    relatesToMemberId: number;
    relationType: "Father" | "Mother" | "Husband" | "Wife";
    dom?: string;
    updatedAt: string;
    updatedBy: string;
    isNewEntry: boolean;
    _isDirty?: boolean;
  }