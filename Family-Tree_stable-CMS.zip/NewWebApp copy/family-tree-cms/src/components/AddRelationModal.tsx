import { useState, useMemo } from "react";
import Button from "./Button";
import type { FamilyMember, FamilyRelation } from "../types/family";
import { createRelations } from "../services/relationService";

interface Props {
  selectedMember: FamilyMember;
  allMembers: FamilyMember[];
  relations: FamilyRelation[];
  currentUserEmail: string;
  onClose: () => void;
  onSave: (
    secondMember: FamilyMember,
    relationType: FamilyRelation["relationType"],
    dom?: string
  ) => void;
}

export default function AddRelationModal({
  selectedMember,
  allMembers,
  relations,
  currentUserEmail,
  onClose,
  onSave,
}: Props) {
  const today = new Date().toISOString().split("T")[0];

  const [relationType, setRelationType] =
    useState<FamilyRelation["relationType"] | "">("");

  const [search, setSearch] = useState("");
  const [selectedSecondMember, setSelectedSecondMember] =
    useState<FamilyMember | null>(null);

  const [dom, setDom] = useState("");

  /* ===============================
     RELATION OPTIONS
  =============================== */

  const relationOptions =
    selectedMember.gender === "F"
      ? ["Father", "Mother", "Husband"]
      : ["Father", "Mother", "Wife"];

  /* ===============================
     FILTER MEMBERS
  =============================== */

  const filteredMembers = allMembers
    .filter((m) => m.memberId !== selectedMember.memberId)
    .filter((m) => {
      if (relationType === "Father") return m.gender === "M";
      if (relationType === "Mother") return m.gender === "F";
      if (relationType === "Husband") return m.gender === "M";
      if (relationType === "Wife") return m.gender === "F";
      return true;
    })
    .filter((m) =>
      m.fullName.toLowerCase().includes(search.toLowerCase())
    );

  /* ===============================
     PREVIEW USING SERVICE LOGIC
  =============================== */
  
  const previewResult = useMemo(() => {
    if (!relationType || !selectedSecondMember) return null;
  
    return createRelations(
      selectedMember,
      selectedSecondMember,
      relationType,
      relations,
      allMembers,
      currentUserEmail,
      dom
    );
  }, [
    relationType,
    selectedSecondMember,
    dom,
    relations,
    selectedMember,
    allMembers,
    currentUserEmail,
  ]);
  
  /* ===============================
     READABLE SENTENCE
  =============================== */

  const getMemberById = (id: number) =>
    allMembers.find((m) => m.memberId === id);

  const buildReadableSentence = (relation: FamilyRelation) => {
    const primary = getMemberById(relation.relatedMemberId);
    const other = getMemberById(relation.relatesToMemberId);

    if (!primary || !other) return "";

    if (relation.relationType === "Father") {
      return `Adding ${other.fullName} as Father of ${primary.fullName}.`;
    }

    if (relation.relationType === "Mother") {
      return `Adding ${other.fullName} as Mother of ${primary.fullName}.`;
    }

    if (relation.relationType === "Wife") {
      return `Adding ${other.fullName} as Wife of ${primary.fullName}.`;
    }

    if (relation.relationType === "Husband") {
      return `Adding ${other.fullName} as Husband of ${primary.fullName}.`;
    }

    return "";
  };

  /* ===============================
     SAVE
  =============================== */

  const handleSave = () => {
    if (!selectedSecondMember || !relationType) return;

    onSave(selectedSecondMember, relationType, dom);
  };

  /* ===============================
     UI
  =============================== */

  return (
    <div className="modal-overlay">
      <div className="modal-container">
        <div className="modal-title">
          Add relation for {selectedMember.fullName}
        </div>

        {/* Relation Type */}
        <select
          className="input-field"
          value={relationType}
          onChange={(e) =>
            setRelationType(
              e.target.value as FamilyRelation["relationType"]
            )
          }
        >
          <option value="">Select relation</option>
          {relationOptions.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>

        {/* Search */}
        <input
          className="input-field"
          placeholder="Search member..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {/* Member List */}
        <div style={{ maxHeight: 150, overflowY: "auto" }}>
          {filteredMembers.map((m) => (
            <div
              key={m.memberId}
              className={`member-item ${
                selectedSecondMember?.memberId === m.memberId
                  ? "active"
                  : ""
              }`}
              onClick={() => setSelectedSecondMember(m)}
            >
              {m.fullName}
            </div>
          ))}
        </div>

        {/* DOM for spouse */}
        {(relationType === "Wife" ||
          relationType === "Husband") && (
          <input
            className="input-field"
            type="date"
            max={today}
            value={dom}
            onChange={(e) => setDom(e.target.value)}
          />
        )}

        {/* Preview */}
        {previewResult && !previewResult.success && (
          <div style={{ marginTop: 15, color: "red" }}>
            {previewResult.error}
          </div>
        )}
        {previewResult &&
          previewResult.success &&
          previewResult.relations &&
          previewResult.relations.length > 0 && (
          <div style={{ marginTop: 15 }}>
            <strong>Relations that will be created:</strong>
            {previewResult?.relations?.map((r, i) => (
              <div key={i} style={{ marginTop: 6 }}>
                <div>{buildReadableSentence(r)}</div>
                <div style={{ fontSize: 12, opacity: 0.6 }}>
                  {`{ relatedMemberId=${r.relatedMemberId}, relatesToMemberId=${r.relatesToMemberId}, relationType="${r.relationType}" }`}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="modal-actions">
          <Button onClick={onClose}>Cancel</Button>
          <Button
            variant="primary"
            disabled={
              !selectedSecondMember || !relationType
            }
            onClick={handleSave}
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  );
}