import { useState, useRef, useEffect } from "react";
import Button from "./Button";
import { INDIA_STATES } from "../constants/states";
import { getGotraHindi, formatGotra } from "../utils/laungageUtil";

interface Props {
  onClose: () => void;
  onSave: (member: any) => void;
  gotras: string[]; 
}

export default function AddMemberModal({ onClose, onSave, gotras }: Props) {
  const today = new Date().toISOString().split("T")[0];
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    nameRef.current?.focus();
  }, []);

  const [form, setForm] = useState({
    fullName: "",
    gotra: "",
    gender: "M",
    dob: "",
    isLiving: true,
    dod: "",
    city: "",
    state: "Madhya Pradesh",
    mobile: "",
  });

  const [errors, setErrors] = useState<any>({});
  const [showGotraDropdown, setShowGotraDropdown] = useState(false);
  const [highlightIndex, setHighlightIndex] = useState(0);

  const filteredGotras = gotras.filter((g) =>
    g.toLowerCase().includes(form.gotra.toLowerCase())
  );

  const validate = () => {
    const newErrors: any = {};

    if (!form.fullName.trim()) newErrors.name = "Name is required";
    if (!form.gotra.trim()) newErrors.gotra = "Gotra is required";
    if (!form.city.trim()) newErrors.city = "City is required";
    if (!form.dob) newErrors.dob = "Date of Birth required";
    if (!form.isLiving && !form.dod)
      newErrors.dod = "Date of Death required";
    if (form.mobile && form.mobile.length !== 10)
      newErrors.mobile = "Mobile must be 10 digits";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;

    onSave({
      fullName: form.fullName,
      gotra: form.gotra,
      gender: form.gender,
      dob: form.dob,
      dod: form.isLiving ? "" : form.dod,
      isLiving: form.isLiving,
      city: form.city,
      state: form.state,
      mobile: form.mobile,
    });
  };

  return (
    <div className="modal-overlay">
      <div className="modal-container">
        <div className="modal-title">Add New Member</div>

        {/* Name */}
        <input
          ref={nameRef}
          className="input-field"
          placeholder="Name *"
          value={form.fullName}
          onChange={(e) =>
            setForm({ ...form, fullName: e.target.value })
          }
        />
        {errors.name && <div className="error-text">{errors.name}</div>}

        {/* Gotra */}
        <div style={{ position: "relative", width: "80%" }}>
          <input
            className="input-field"
            placeholder="Gotra *"
            value={form.gotra}
            onFocus={() => setShowGotraDropdown(true)}
            onChange={(e) => {
              const value = e.target.value;
              setForm({ ...form, gotra: formatGotra(value) });
              setShowGotraDropdown(true);
              setHighlightIndex(0);
            }}
            onKeyDown={(e) => {
              if (!showGotraDropdown) return;

              if (e.key === "ArrowDown") {
                e.preventDefault();
                setHighlightIndex((prev) =>
                  prev < filteredGotras.length - 1 ? prev + 1 : prev
                );
              }

              if (e.key === "ArrowUp") {
                e.preventDefault();
                setHighlightIndex((prev) =>
                  prev > 0 ? prev - 1 : 0
                );
              }

              if (e.key === "Enter") {
                e.preventDefault();

                if (filteredGotras[highlightIndex]) {
                  setForm({
                    ...form,
                    gotra: filteredGotras[highlightIndex],
                  });
                }

                setShowGotraDropdown(false);
              }

              if (e.key === "Escape") {
                setShowGotraDropdown(false);
              }
            }}
          />

          {showGotraDropdown && form.gotra && (
            <div className="dropdown-list">

              {filteredGotras.map((g, index) => {
                const hindi = getGotraHindi(g);

                return (
                  <div
                    key={g}
                    className={`dropdown-item ${
                      index === highlightIndex ? "active-item" : ""
                    }`}
                    onMouseEnter={() => setHighlightIndex(index)}
                    onClick={() => {
                      setForm({ ...form, gotra: g });
                      setShowGotraDropdown(false);
                    }}
                  >
                    {g}
                    {hindi && (
                      <span style={{ opacity: 0.6, marginLeft: 8 }}>
                        - {hindi}
                      </span>
                    )}
                  </div>
                );
              })}

              {/* Create new option */}
              {!gotras.some(
                (g) =>
                  g.toLowerCase() === form.gotra.toLowerCase()
              ) && (
                <div
                  className="dropdown-item"
                  style={{ fontStyle: "italic", opacity: 0.7 }}
                >
                  Create "{form.gotra}"
                </div>
              )}

            </div>
          )}
        </div>
        {errors.gotra && <div className="error-text">{errors.gotra}</div>}

        {/* Gender */}
        <select
          className="input-field"
          value={form.gender}
          onChange={(e) =>
            setForm({ ...form, gender: e.target.value })
          }
        >
          <option value="M">Male</option>
          <option value="F">Female</option>
        </select>

        {/* DOB */}
        <input
          className="input-field"
          type="date"
          max={today}
          value={form.dob}
          onChange={(e) =>
            setForm({ ...form, dob: e.target.value })
          }
        />
        {errors.dob && <div className="error-text">{errors.dob}</div>}

        {/* Living Toggle */}
        <div className="toggle-row">
          <input
            type="checkbox"
            checked={form.isLiving}
            onChange={() =>
              setForm({ ...form, isLiving: !form.isLiving })
            }
          />
          <span>Living</span>
        </div>

        {!form.isLiving && (
          <>
            <input
              className="input-field"
              type="date"
              max={today}
              value={form.dod}
              onChange={(e) =>
                setForm({ ...form, dod: e.target.value })
              }
            />
            {errors.dod && (
              <div className="error-text">{errors.dod}</div>
            )}
          </>
        )}

        {/* City */}
        <input
          className="input-field"
          placeholder="City/Place *"
          value={form.city}
          onChange={(e) =>
            setForm({ ...form, city: e.target.value })
          }
        />
        {errors.city && <div className="error-text">{errors.city}</div>}

        {/* State */}
        <select
          className="input-field"
          value={form.state}
          onChange={(e) =>
            setForm({ ...form, state: e.target.value })
          }
        >
          {INDIA_STATES.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>

        {/* Mobile */}
        <input
          className="input-field"
          type="number"
          placeholder="Mobile (optional)"
          value={form.mobile}
          onChange={(e) =>
            setForm({
              ...form,
              mobile: e.target.value.slice(0, 10),
            })
          }
        />
        {errors.mobile && (
          <div className="error-text">{errors.mobile}</div>
        )}

        <div className="modal-actions">
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={handleSave}>
            Save
          </Button>
        </div>
      </div>
    </div>
  );
}
