import React from "react";
import "../styles/global.css";

interface SectionProps {
  title: string;
  children: React.ReactNode;
}

export default function Section({
  title,
  children,
}: SectionProps) {
  return (
    <>
      <h3>{title}</h3>
      <hr />
      {children}
    </>
  );
}
