import React from "react";
import "../styles/global.css";

interface PanelLayoutProps {
  left: React.ReactNode;
  right: React.ReactNode;
}

export default function PanelLayout({
  left,
  right,
}: PanelLayoutProps) {
  return (
    <div className="main-layout">
      <div className="left-panel">{left}</div>
      <div className="right-panel">{right}</div>
    </div>
  );
}
