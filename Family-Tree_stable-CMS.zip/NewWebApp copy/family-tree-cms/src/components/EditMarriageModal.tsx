import { useState } from "react";
import Button from "./Button";

interface Props {
  memberId: number;
  spouseId: number;
  relations: any[];
  onClose: () => void;
  onSave: (newDom: string) => void;
}

export default function EditMarriageModal({
  memberId, 
  spouseId,
  relations,
  onClose,
  onSave,
}: Props) {

  const existingRelation = relations.find(
    (r) =>
      (r.relationType === "Wife" ||
      r.relationType === "Husband") &&
      (r.relatedMemberId === memberId ||
      r.relatedMemberId === spouseId)
  );

  const [dom, setDom] = useState(existingRelation?.dom || "");

  return (
    <div className="modal-overlay">
      <div className="modal-container">
        <div className="modal-title">
          Edit Date of Marriage
        </div>

        <input
          type="date"
          className="input-field"
          value={dom}
          onChange={(e) => setDom(e.target.value)}
        />

        <div className="modal-actions">
          <Button onClick={onClose}>Cancel</Button>
          <Button
            variant="primary"
            onClick={() => onSave(dom)}
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  );
}