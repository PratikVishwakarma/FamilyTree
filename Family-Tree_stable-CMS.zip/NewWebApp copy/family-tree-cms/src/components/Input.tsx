import React from "react";
import "../styles/global.css";

interface InputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function Input({
  value,
  onChange,
  placeholder,
}: InputProps) {
  return (
    <input
      className="input-field"
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}
