import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFunctions } from "firebase/functions";

const firebaseConfig = {
  apiKey: "AIzaSyAJWTsxaQyP3RxB60dC4rHGSowU0HCQtC8",
  authDomain: "samaj-family-tree.firebaseapp.com",
  projectId: "samaj-family-tree",
  storageBucket: "samaj-family-tree.firebasestorage.app",
  messagingSenderId: "1048584942441",
  appId: "1:1048584942441:web:ac159e9140ed0cf98d03f8",
  measurementId: "G-T9MG34P2H1"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const storage = getStorage(app);

/**
 * IMPORTANT:
 * Region must match deployed functions region.
 * Default is usually "us-central1"
 */
export const functions = getFunctions(app, "us-central1");
