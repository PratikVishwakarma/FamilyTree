import Dexie from "dexie";

export interface Member {
  memberId: number;
  fullName: string;
  gender: string;
  dob: string;
  city: string;
  state: string;
  gotra: string;
  isLiving: boolean;
}

export interface Relation {
  id?: number; // auto increment
  relatedMemberId: number;
  relatesToMemberId: number;
  relationType: string;
}

class FamilyTreeDB extends Dexie {
  members!: Dexie.Table<Member, number>;
  relations!: Dexie.Table<Relation, number>;

  constructor() {
    super("FamilyTreeCMS");

    this.version(1).stores({
      members: "memberId, fullName",
      relations: "++id, relatedMemberId, relatesToMemberId"
    });
  }
}

export const db = new FamilyTreeDB();
