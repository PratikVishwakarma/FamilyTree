package com.pratik.learning.familyTree.presentation.screen

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.room.util.TableInfo
import com.pratik.learning.familyTree.navigation.AddMember
import com.pratik.learning.familyTree.presentation.component.Container
import com.pratik.learning.familyTree.presentation.component.FilterChip
import com.pratik.learning.familyTree.presentation.component.MemberInfoSectionSmall
import com.pratik.learning.familyTree.presentation.component.TimelineRow
import com.pratik.learning.familyTree.presentation.component.eventIcon
import com.pratik.learning.familyTree.presentation.viewmodel.AdminViewModel
import com.pratik.learning.familyTree.presentation.viewmodel.AppViewModel
import com.pratik.learning.familyTree.presentation.viewmodel.MemberDetailsViewModel
import com.pratik.learning.familyTree.utils.HiText
import com.pratik.learning.familyTree.utils.inHindi

@Composable
fun AdminScreen(
    navController: NavController,
    appVM: AppViewModel,
    adminVM: AdminViewModel = hiltViewModel()
) {
    val isLoggedIn by adminVM.isLoggedIn.collectAsState()
    val uiState by adminVM.uiState.collectAsState()
    BackHandler {
        appVM.closeApp()
    }

    Container(
        title = "प्रशासक प्रवेश",
        paddingValues = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
    ) {

        if (isLoggedIn) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = "आप प्रशासक के रूप में लॉगिन हैं",
                    style = MaterialTheme.typography.titleMedium
                )

                OutlinedButton(
                    onClick = { navController.navigate(AddMember) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("➕ नया सदस्य जोड़ें")
                }

                OutlinedButton(
                    onClick = { adminVM.logOut(navController) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("लॉग आउट")
                }
            }

        } else {

            var email by rememberSaveable { mutableStateOf("") }
            var password by rememberSaveable { mutableStateOf("") }


            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = "प्रशासक लॉगिन",
                    style = typography.headlineSmall
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "डेटा की शुद्धता और सुरक्षा सुनिश्चित करने के लिए केवल अधिकृत प्रशासक (Admin) ही जानकारी जोड़ या अपडेट कर सकते हैं।",
                    style = typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        adminVM.clearErrors()
                    },
                    label = { Text("ईमेल") },
                    isError = uiState.emailError != null,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                uiState.emailError?.let {
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.align(Alignment.Start)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        adminVM.clearErrors()
                    },
                    label = { Text("पासवर्ड") },
                    isError = uiState.passwordError != null,
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                uiState.passwordError?.let {
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.align(Alignment.Start)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedButton(
                    onClick = {
                        adminVM.validateAndLogin(email, password)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !uiState.isLoading
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            modifier = Modifier.height(18.dp)
                        )
                    } else {
                        Text("लॉगिन करें")
                    }
                }

                uiState.loginError?.let {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}
