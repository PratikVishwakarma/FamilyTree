package com.pratik.learning.familyTree

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.google.firebase.Firebase
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.analytics
import com.pratik.learning.familyTree.navigation.About
import com.pratik.learning.familyTree.navigation.Admin
import com.pratik.learning.familyTree.navigation.AppNavigation
import com.pratik.learning.familyTree.navigation.Home
import com.pratik.learning.familyTree.navigation.MySpace
import com.pratik.learning.familyTree.navigation.SplashRoute
import com.pratik.learning.familyTree.presentation.FancyBottomItem
import com.pratik.learning.familyTree.presentation.component.FancyBottomBar
import com.pratik.learning.familyTree.presentation.viewmodel.AppViewModel
import com.pratik.learning.familyTree.ui.theme.FamilyTreeTheme
import com.pratik.learning.familyTree.utils.enqueueSyncWork
import com.pratik.learning.familyTree.utils.inHindi
import com.pratik.learning.familyTree.utils.logger
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import kotlin.getValue

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private lateinit var analytics: FirebaseAnalytics
    private val appVM: AppViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        analytics = Firebase.analytics
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                appVM.closeAppEvent.collect {
                    logger("closeApp event received")
                    closeApp()
                }
            }
        }
        FamilyTreeApp.isAdmin = appVM.getCurrentUser() != null
        setContent {
            val navController = rememberNavController()
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route
            val isSplash = currentRoute == SplashRoute::class.qualifiedName

            val items = listOf(
                FancyBottomItem(MySpace, "My Space".inHindi(), Icons.Default.Person),
                FancyBottomItem(Home, "Search".inHindi(), Icons.Default.Search),
                FancyBottomItem(Admin, "Admin".inHindi(), Icons.Default.AdminPanelSettings),
                FancyBottomItem(About, "About".inHindi(), Icons.Default.Info)
            )

            val selectedIndex = items.indexOfFirst {
                backStackEntry?.destination?.route == it.route::class.qualifiedName
            }.takeIf { it >= 0 } ?: 1/*(items.size / 2)*/ // Search index

            FamilyTreeTheme {
                Column(
                    Modifier.fillMaxSize()
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        AppNavigation(navController, appVM)
                    }
                    if (!isSplash)
                        FancyBottomBar(
                            items = items,
                            selectedIndex = selectedIndex,
                            onItemSelected = { index ->
                                if (currentRoute != items[index].route::class.qualifiedName) {
                                    navController.navigate(items[index].route) {
                                        popUpTo(Home::class.qualifiedName!!) {
                                            inclusive = false
                                        }
                                        launchSingleTop = true
                                    }
                                }
                            }
                        )
                }
            }
        }
    }

    fun closeApp() {
        logger("closeApp event received initiate upload worker and close the app")
        enqueueSyncWork(this)
        finish()
    }
}
