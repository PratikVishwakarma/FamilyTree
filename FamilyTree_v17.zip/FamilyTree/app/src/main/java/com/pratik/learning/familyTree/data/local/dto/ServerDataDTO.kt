package com.pratik.learning.familyTree.data.local.dto

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
data class ServerDataDTO(
    @SerializedName("familyTree_members")
    val members: List<FamilyMember> = emptyList(),

    @SerializedName("familyTree_relations")
    val relations: List<FamilyRelation> = emptyList()
)