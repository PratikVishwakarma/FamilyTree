package com.pratik.learning.familyTree.presentation.screen

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pratik.learning.familyTree.presentation.component.Container
import com.pratik.learning.familyTree.presentation.component.FamilyWordBackground
import com.pratik.learning.familyTree.presentation.component.MemberInfoSectionSmall
import com.pratik.learning.familyTree.presentation.component.TimelineRow
import com.pratik.learning.familyTree.presentation.component.eventIcon
import com.pratik.learning.familyTree.presentation.viewmodel.AppViewModel
import com.pratik.learning.familyTree.presentation.viewmodel.MemberDetailsViewModel
import com.pratik.learning.familyTree.utils.GOOGLE_FORM_LINK
import com.pratik.learning.familyTree.utils.HiText
import com.pratik.learning.familyTree.utils.inHindi


@Composable
fun AboutAppScreen(appVM: AppViewModel) {
    BackHandler {
        appVM.closeApp()
    }
    Container(
        title = "About".inHindi(),
        paddingValues = PaddingValues(horizontal = 16.dp, 0.dp),
        rightButton = {

        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            FamilyWordBackground()
            Column(
                modifier = Modifier
                    .padding()
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {

                // 🌳 Main Description
                Text(
                    text = "यह आपके परिवार और पूर्वजों की जानकारी को सुरक्षित रखने का एक डिजिटल माध्यम है।",
                    style = typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "इस ऐप के माध्यम से आप अपने परिवार के सदस्यों, रिश्तों और पारिवारिक इतिहास को एक सुरक्षित स्थान पर संरक्षित कर सकते हैं।",
                    style = typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "अपने पूर्वजों को जानें, अपने रिश्तों को समझें और आने वाली पीढ़ियों के लिए अपनी विरासत को संजोकर रखें।",
                    style = typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant
                )

                // ➕ Add Member Section
                Text(
                    text = "परिवार के सदस्य जोड़ना या जानकारी अपडेट करना चाहते हैं?",
                    style = typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "हमारे परिवार वृक्ष को और अधिक पूर्ण और सटीक बनाने में सहयोग करें। कृपया आधिकारिक फॉर्म के माध्यम से जानकारी भेजें।",
                    style = typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Button(
                    onClick = { appVM.openExternalLink(GOOGLE_FORM_LINK) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("➕ परिवार सदस्य जोड़ें")
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant
                )

                // 🇮🇳 Initiative Message
                Text(
                    text = "यह एक छोटा सा प्रयास है अपने पूर्वजों की यादों, परंपराओं और पारिवारिक विरासत को सुरक्षित रखने का।",
                    style = typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "आइए मिलकर अपनी वंश परंपरा को डिजिटल रूप में संजोएं और आने वाली पीढ़ियों को अपनी जड़ों से जोड़ें।",
                    style = typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "परिवार मूल्यों और परंपराओं के प्रति सम्मान के साथ निर्मित।",
                    style = typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}