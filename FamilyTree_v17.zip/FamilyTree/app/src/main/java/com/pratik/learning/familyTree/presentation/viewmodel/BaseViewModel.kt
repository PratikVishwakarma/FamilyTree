package com.pratik.learning.familyTree.presentation.viewmodel

import androidx.lifecycle.ViewModel

abstract class BaseViewModel: ViewModel()