package com.pratik.learning.familyTree.utils

import android.content.Context
import android.net.ConnectivityManager
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.pratik.learning.familyTree.data.repository.FamilyTreeRepository
import com.pratik.learning.familyTree.utils.SyncPrefs.getIsDataUpdateRequired
import com.pratik.learning.familyTree.utils.SyncPrefs.setIsDataUpdateRequired
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

@HiltWorker
class SyncOnExitWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val repository: FamilyTreeRepository
) : CoroutineWorker(context, params) {

    init {
        logger("SyncWorker", "Worker created")
    }

    override suspend fun doWork(): Result {
        return try {
            if (!getIsDataUpdateRequired(applicationContext)) {
                logger("SyncWorker", "No data update required")
                return Result.success()
            }

            repository.syncDataToFirebase()

            setIsDataUpdateRequired(applicationContext, false)

            Result.success()

        } catch (e: Exception) {

            logger("SyncWorker", "Error: ${e.message}")

            // Retry only if network or transient error
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure()
            }
        }
    }
}