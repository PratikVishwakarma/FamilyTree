package com.pratik.learning.familyTree.presentation.viewmodel

import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pratik.learning.familyTree.FamilyTreeApp.Companion.isAdmin
import com.pratik.learning.familyTree.data.repository.FamilyTreeRepository
import com.pratik.learning.familyTree.data.repository.SyncState
import com.pratik.learning.familyTree.utils.SyncPrefs.getIsDataUpdateRequired
import com.pratik.learning.familyTree.utils.SyncPrefs.setIsDataUpdateRequired
import com.pratik.learning.familyTree.utils.SyncPrefs.shouldSync
import com.pratik.learning.familyTree.utils.logger
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val familyTreeRepository: FamilyTreeRepository,
    @ApplicationContext val context: Context
) : BaseViewModel() {

    var relationType = ""

    private val _syncState = MutableStateFlow<SyncState?>(null)
    val syncState: StateFlow<SyncState?> = _syncState

    private val _isDataLoaded = MutableStateFlow(false)
    var isDataLoaded: StateFlow<Boolean> = _isDataLoaded

    private val _error = MutableStateFlow("")
    var error: StateFlow<String> = _error

    private val _isInternetRequired = MutableStateFlow(false)
    val isInternetRequired = _isInternetRequired.asStateFlow()


    private val _dataLoadingMessage = MutableStateFlow("डेटा लोड हो रहा है...")
    val dataLoadingMessage: StateFlow<String> = _dataLoadingMessage

    private suspend fun checkInternetAndSync() {
        val isRequired = familyTreeRepository.isNoDataAndNoInternet()
        logger("checkInternetAndSync:: isRequired = $isRequired")
        if (isRequired) {
            _isInternetRequired.value = true
        } else {
            _isInternetRequired.value = false
            if (shouldSync(context) && familyTreeRepository.verifyInternetAccess()) {
                logger("checkInternetAndSync:: Downloading data from server is required")
                downloadDataFromServer()
            } else {
                delay(1500)
                _isDataLoaded.value = true
            }
        }
    }

    fun retryDataSync() {
        logger("retryDataSync called")
        _isInternetRequired.value = false
        viewModelScope.launch {
            if (familyTreeRepository.verifyInternetAccess())
                checkInternetAndSync()
            else {
                redirectTONetwork()
            }
        }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            logger("init called")
            if (isAdmin && getIsDataUpdateRequired(context) && familyTreeRepository.verifyInternetAccess()) {
                logger("Uploading data to server is required")
                uploadDataOnServer()
            }
            checkInternetAndSync()
        }
    }

    private fun uploadDataOnServer() {
        viewModelScope.launch(Dispatchers.IO) {
            familyTreeRepository.syncDataToFirebase(isAlsoDownload = true)
        }
    }

    private fun downloadDataFromServer() {
        viewModelScope.launch(Dispatchers.IO) {
//            _isDataLoaded.value = familyTreeRepository.downloadDataFromServer()
            familyTreeRepository.downloadDataFromServer()
        }

        familyTreeRepository.dataEventFlow
            .distinctUntilChanged()
            .onEach { state ->
                when (state) {
                    is SyncState.Downloading -> {
                        logger("downloadDataFromServer: Downloading: ${state.percent} %")
                        _dataLoadingMessage.value = "डेटा डाउनलोड हो रहा है..."
                        _isDataLoaded.value = true
                    }

                    is SyncState.Storing -> {
                        logger("downloadDataFromServer: Storing: ${state.percent} %")
                        _dataLoadingMessage.value = "${state.percent}% डेटा लोड हो गया..."
                        _isDataLoaded.value = true
                    }

                    is SyncState.Success -> {
                        logger("downloadDataFromServer: Success:")
                        _isDataLoaded.value = false
                    }

                    is SyncState.Error -> {
                        _isDataLoaded.value = false
                    }
                }
            }
            .launchIn(viewModelScope)
    }

    /**
     * to open the network settings
     * */
    private fun redirectTONetwork() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).apply { addFlags(FLAG_ACTIVITY_NEW_TASK) })
        } else {
            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).apply { addFlags(FLAG_ACTIVITY_NEW_TASK) })
        }
    }

}

