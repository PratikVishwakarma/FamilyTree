package com.pratik.learning.familyTree.presentation.viewmodel

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.pratik.learning.familyTree.utils.logger
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AppViewModel @Inject constructor(
    private val auth: FirebaseAuth,
    @ApplicationContext val context: Context
): ViewModel() {
    private val _closeAppEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val closeAppEvent = _closeAppEvent.asSharedFlow()

    fun closeApp() {
        logger("closeApp called")
        viewModelScope.launch {
            _closeAppEvent.emit(Unit)
        }
    }

    fun getCurrentUser(): FirebaseUser? {
        return auth.currentUser
    }

    fun openExternalLink(url: String) {
        val uri = Uri.parse(url)

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
            addFlags(FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                context,
                "लिंक खोलने में समस्या",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}