package com.pratik.learning.familyTree.data.repository

import androidx.annotation.Keep

@Keep
sealed class SyncState {
    data class Downloading(val percent: Int) : SyncState()
    data class Storing(val percent: Int) : SyncState()
    object Success : SyncState()
    data class Error(val message: String?) : SyncState()
}