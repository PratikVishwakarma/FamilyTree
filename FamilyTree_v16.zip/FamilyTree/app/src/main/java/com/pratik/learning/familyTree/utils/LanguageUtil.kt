package com.pratik.learning.familyTree.utils

object HiText {
    const val BORN_ = "का जन्म"
    const val DIED = "और निधन"
    const val ON = "को"
    const val MALE_CHILD = "पुत्र"
    const val FEMALE_CHILD = "पुत्री"
    const val IS = "हैं"
    const val AND = "और"
    const val MARRIAGE = "विवाह"
    const val CHILDREN = "बच्चे"
    const val HAS = "उनके"
    const val HAS_SINGLE = "उनका"
    const val SHREE = "श्री"
    const val SHREEMATI = "श्रीमती"
    const val VE = "वे"
    const val HUE = "वे"
    const val ONLY_ONE = "केवल एक"
    const val MARRIED_TO = "से विवाह"
    const val DIED_ON = "का निधन"
    const val DIEDED = "निधन"
    const val BORN = "जन्म"
    const val SON_BORN = "पुत्र प्राप्ति"
    const val DAUGHTER_BORN = "पुत्री प्राप्ति"
    const val TIMELINE = "जीवन रेखा"

}


fun String.inHindi(): String {
    return when (this.lowercase().trim()) {
        RELATION_TYPE_FATHER.lowercase() -> "पिता"
        RELATION_TYPE_MOTHER.lowercase() -> "माता"
        RELATION_TYPE_SON_IN_LAW.lowercase() -> "दामाद"
        RELATION_TYPE_DAUGHTER_IN_LAW.lowercase() -> "बहू"
        RELATION_TYPE_FATHER_IN_LAW.lowercase() -> "ससुर"
        RELATION_TYPE_MOTHER_IN_LAW.lowercase() -> "सास"
        RELATION_TYPE_BROTHER.lowercase() -> "भाई"
        RELATION_TYPE_SISTER.lowercase() -> "बहन"
        RELATION_TYPE_HUSBAND.lowercase() -> "पति"
        RELATION_TYPE_WIFE.lowercase() -> "पत्नी"
        RELATION_TYPE_SON.lowercase() -> "पुत्र"
        RELATION_TYPE_DAUGHTER.lowercase() -> "पुत्री"
        RELATION_TYPE_GRANDFATHER_F.lowercase() -> "दादा जी"
        RELATION_TYPE_GRANDMOTHER_F.lowercase()-> "दादी जी"
        RELATION_TYPE_GRANDFATHER_M.lowercase() -> "नाना जी"
        RELATION_TYPE_GRANDMOTHER_M.lowercase() -> "नानी जी"
        RELATION_TYPE_GRANDCHILD.lowercase() -> "पोता"
        RELATION_TYPE_GRANDCHILD_F.lowercase() -> "पोती"
        RELATION_TYPE_GREAT_GRANDCHILD.lowercase() -> "परपोता"
        RELATION_TYPE_GREAT_GREAT_GRANDCHILD.lowercase() -> "पर परपोता"
        RELATION_TYPE_GREAT____GRANDCHILD.lowercase() -> "पर...परपोता"
        GENDER_TYPE_MALE.lowercase() -> "पुरुष"
        GENDER_TYPE_FEMALE.lowercase() -> "महिला"
        RELATION_TYPE_GRANDCHILD_MOTHER_SIDE.lowercase() -> "नाती"
        RELATION_TYPE_GRANDCHILD_MOTHER_SIDE_F.lowercase() -> "नवासी"
        RELATION_TYPE_COUSIN_BROTHER_FATHER_SIDE.lowercase() -> "चचेरा भाई"
        RELATION_TYPE_COUSIN_SISTER_FATHER_SIDE.lowercase() -> "चचेरी बहिन"
        RELATION_TYPE_COUSIN_BROTHER_MOTHER_SIDE.lowercase() -> "ममेरा भाई"
        RELATION_TYPE_COUSIN_SISTER_MOTHER_SIDE.lowercase() -> "ममेरी बहिन"
        RELATION_TYPE_COUSIN_SISTER.lowercase() -> "चचेरी/ममेरी बहिन"
        RELATION_TYPE_COUSIN_BROTHER.lowercase() -> "चचेरा/ममेरा भाई"
        RELATION_TYPE_ELDER_BROTHER_OF_FATHER.lowercase() -> "ताऊजी/बड़े पापा"
        RELATION_TYPE_WIFE_OF_ELDER_BROTHER_OF_FATHER.lowercase() -> "ताईजी/बड़ी मम्मी"
        RELATION_TYPE_YOUNGER_BROTHER_OF_FATHER.lowercase() -> "चाचा जी"
        RELATION_TYPE_WIFE_OF_YOUNGER_BROTHER_OF_FATHER.lowercase() -> "चाची जी"
        RELATION_TYPE_SISTER_OF_FATHER.lowercase() -> "बुआ जी"
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_FATHER.lowercase() -> "फूफा जी"
        RELATION_TYPE_SON_OF_BROTHER.lowercase() -> "भतीजा"
        RELATION_TYPE_DAUGHTER_OF_BROTHER.lowercase() -> "भतीजी"
        RELATION_TYPE_BROTHER_OF_MOTHER.lowercase() -> "मामा जी"
        RELATION_TYPE_WIFE_OF_BROTHER_OF_MOTHER.lowercase() -> "मामी जी"
        RELATION_TYPE_SISTER_OF_MOTHER.lowercase() -> "मौसी जी"
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_MOTHER.lowercase() -> "मौसा जी"
        RELATION_TYPE_SON_OF_SISTER.lowercase() -> "भांजा"
        RELATION_TYPE_DAUGHTER_OF_SISTER.lowercase() -> "भांजी"
        RELATION_TYPE_HUSBAND_OF_SISTER.lowercase() -> "जीजा जी"
        RELATION_TYPE_WIFE_OF_BROTHER.lowercase() -> "भाभी जी"
        RELATION_TYPE_ELDER_BROTHER_OF_HUSBAND.lowercase() -> "जेठ जी"
        RELATION_TYPE_WIFI_OF_ELDER_BROTHER_OF_HUSBAND.lowercase() -> "जेठानी जी"
        RELATION_TYPE_YOUNGER_BROTHER_OF_HUSBAND.lowercase() -> "देवर जी"
        RELATION_TYPE_WIFI_OF_YOUNGER_BROTHER_OF_HUSBAND.lowercase() -> "देवरानी जी"
        RELATION_TYPE_SISTER_OF_HUSBAND.lowercase() -> "ननद"
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_HUSBAND.lowercase() -> "नन्दोई"
        RELATION_TYPE_SISTER_OF_WIFI.lowercase() -> "साली"
        RELATION_TYPE_BROTHER_OF_WIFI.lowercase() -> "साला"
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_WIFI.lowercase() -> "साडू"
        "parents" -> "माता-पीता"
        "spouse" -> "जीवन साथी"
        "in-laws" -> "सास-ससुर"
        "siblings" -> "भाई-बहन"
        "children" -> "बच्चे"
        "father-grandparents" -> "दादा-दादी"
        "mother-grandparents" -> "नाना-नानी"
        "grandchildren" -> "पोता-पोती"
        "mother-uncle and aunt" -> "मामा-मामी / मौसा-मौसी"
        "father-uncle and aunt" -> "ताऊ-तेजी / चाचा-चाची / बुआ-फूफाजी"
        "in-laws side" -> "ससुराल पक्ष"
        "mother side" -> "ननिहाल पक्ष"
        "spouse siblings" -> "साला-साली / भाभी"
        "full name" -> "नाम"
        "living" -> "जीवित"
        "deceased", "dead" -> "स्वर्गवासी"
        "gotra" -> "गोत्र"
        "dob", "date of birth" -> "जन्मदिन"
        "dod", "date of death" -> "मृत्यु दिवस"
        "Mobile Number" -> "मोबाइल नंबर"
        "search" -> "खोजेंं"
        "unmarried" -> "अविवाहित"
        "add member" -> "सदस्य जोड़ें"
        "member","members" -> "सदस्य"
        "add relation" -> "संबंध जोड़ें"
        "see ancestry" -> "वंशावली देखें"
        "delete member" -> "सदस्य हटाएं"
        "member details" -> "सदस्य विवरण"
        "select member" -> "सदस्य का चयन करें"
        "relation" -> "संबंध"
        "please select a relation" -> "कृपया एक संबंध चुनें"
        "please select a related person" -> "कृपया संबंधित व्यक्ति का चयन करें"
        "person cannot be related to themselves" -> "व्यक्ति स्वयं से संबंधित नहीं हो सकता"
        "edit" -> "परिवर्तन"
        "are you sure you want to delete this member?" -> "क्या आप वाकई इस सदस्य को हटाना चाहते हैं?"
        "yes" -> "हाँ"
        "no", "cancel" -> "नहीं"
        "delete all relations" -> "सभी संबंध हटाएँ"
        "are you sure you want to delete all the relations for member?" -> "क्या आप वाकई सदस्य के सभी संबंध हटाना चाहते हैं?                "
        "please scroll left or down to see whole family tree" -> "कृपया संपूर्ण परिवार वृक्ष देखने के लिए बाईं ओर या नीचे स्क्रॉल करें"
        "it's not me" -> "यह में नहीं हु।"
        "years" -> "वर्ष"
        "select user" -> "सदस्य चुने"
        "admin" -> "एडमिन"
        "login" -> "लॉगिन"
        "my space" -> "माय स्पेस"
        "about" -> "अबाउट"
        "email" -> "ईमेल"
        "password" -> "पासवर्ड"
        "email cannot be empty" -> "ईमेल खाली नहीं हो सकता"
        "invalid email format" -> "सही ईमेल प्रारूप डालें"
        "password cannot be empty" -> "पासवर्ड खाली नहीं हो सकता।"
        "password must be greater than 4 characters" -> "पासवर्ड 4 अक्षरों से अधिक का होना चाहिए।"
        "incorrect email or password" -> "गलत ईमेल या पासवर्ड"
        else -> this
    }
}


fun String.relationTextInHindi(): String {
    return when (this) {
        RELATION_TYPE_FATHER -> "के पिता"
        RELATION_TYPE_MOTHER -> "की माता"
        RELATION_TYPE_FATHER_IN_LAW -> "ससुर"
        RELATION_TYPE_MOTHER_IN_LAW -> "सास"
        RELATION_TYPE_BROTHER -> "भाई"
        RELATION_TYPE_SISTER -> "बहन"
        RELATION_TYPE_HUSBAND -> "के पति"
        RELATION_TYPE_WIFE -> "की पत्नी"
        RELATION_TYPE_SON -> "का पुत्र"
        RELATION_TYPE_DAUGHTER -> "की पुत्री"
        RELATION_TYPE_GRANDFATHER_F -> "दादा जी"
        RELATION_TYPE_GRANDMOTHER_F -> "दादीजी"
        RELATION_TYPE_GRANDFATHER_M -> "नाना जी"
        RELATION_TYPE_GRANDMOTHER_M -> "नानी जी"
        RELATION_TYPE_DAUGHTER_IN_LAW -> "बहू"
        RELATION_TYPE_SON_IN_LAW -> "दामाद"
        GENDER_TYPE_MALE -> "पुरुष"
        GENDER_TYPE_FEMALE -> "महिला"
        RELATION_TYPE_GRANDCHILD -> "पोता"
        RELATION_TYPE_GRANDCHILD_F -> "पोती"
        RELATION_TYPE_GRANDCHILD_MOTHER_SIDE -> "नाती"
        RELATION_TYPE_GRANDCHILD_MOTHER_SIDE_F -> "नवासी"
        RELATION_TYPE_COUSIN_BROTHER_FATHER_SIDE -> "चचेरा भाई"
        RELATION_TYPE_COUSIN_SISTER_FATHER_SIDE -> "चचेरी बहिन"
        RELATION_TYPE_COUSIN_BROTHER_MOTHER_SIDE -> "ममेरा भाई"
        RELATION_TYPE_COUSIN_SISTER_MOTHER_SIDE -> "ममेरी बहिन"
        RELATION_TYPE_COUSIN_SISTER -> "चचेरी/ममेरी बहिन"
        RELATION_TYPE_COUSIN_BROTHER -> "चचेरा/ममेरा भाई"
        RELATION_TYPE_ELDER_BROTHER_OF_FATHER -> "ताऊजी/बड़े पापा"
        RELATION_TYPE_WIFE_OF_ELDER_BROTHER_OF_FATHER -> "ताईजी/बड़ी मम्मी"
        RELATION_TYPE_YOUNGER_BROTHER_OF_FATHER -> "चाचा जी"
        RELATION_TYPE_WIFE_OF_YOUNGER_BROTHER_OF_FATHER -> "चाची जी"
        RELATION_TYPE_SISTER_OF_FATHER -> "बुआ जी"
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_FATHER -> "फूफा जी"
        RELATION_TYPE_SON_OF_BROTHER -> "भतीजा"
        RELATION_TYPE_DAUGHTER_OF_BROTHER -> "भतीजी"
        RELATION_TYPE_BROTHER_OF_MOTHER -> "मामा जी"
        RELATION_TYPE_WIFE_OF_BROTHER_OF_MOTHER -> "मामी जी"
        RELATION_TYPE_SISTER_OF_MOTHER -> "मौसी जी"
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_MOTHER -> "मौसा जी"
        RELATION_TYPE_SON_OF_SISTER -> "भांजा"
        RELATION_TYPE_DAUGHTER_OF_SISTER -> "भांजी"
        RELATION_TYPE_HUSBAND_OF_SISTER -> "जीजा जी"
        RELATION_TYPE_WIFE_OF_BROTHER -> "भाभी जी"
        RELATION_TYPE_YOUNGER_BROTHER_OF_HUSBAND -> "देवर जी"
        RELATION_TYPE_SISTER_OF_HUSBAND -> "ननद"
        RELATION_TYPE_SISTER_OF_WIFI -> "साली"
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_WIFI -> "साडू"
        RELATION_TYPE_BROTHER_OF_WIFI -> "साला"
        "Full Name" -> "नाम"
        "Deceased" -> "स्वर्गवासी"
        "Gotra" -> "गोत्र"
        "DOB", "Date of Birth" -> "जन्मदिन"
        "DOD", "Date of Death" -> "मृत्यु दिवस"
        else -> this
    }
}


fun String.getSpouseRelation() : String {
    return when(this) {
        RELATION_TYPE_SON -> RELATION_TYPE_DAUGHTER_IN_LAW
        RELATION_TYPE_DAUGHTER -> RELATION_TYPE_SON_IN_LAW
        RELATION_TYPE_BROTHER -> RELATION_TYPE_WIFE_OF_BROTHER
        RELATION_TYPE_WIFE_OF_BROTHER -> RELATION_TYPE_BROTHER
        RELATION_TYPE_ELDER_BROTHER_OF_FATHER -> RELATION_TYPE_WIFE_OF_ELDER_BROTHER_OF_FATHER
        RELATION_TYPE_WIFE_OF_ELDER_BROTHER_OF_FATHER -> RELATION_TYPE_ELDER_BROTHER_OF_FATHER
        RELATION_TYPE_YOUNGER_BROTHER_OF_FATHER -> RELATION_TYPE_WIFE_OF_YOUNGER_BROTHER_OF_FATHER
        RELATION_TYPE_WIFE_OF_YOUNGER_BROTHER_OF_FATHER -> RELATION_TYPE_YOUNGER_BROTHER_OF_FATHER
        RELATION_TYPE_SISTER_OF_FATHER -> RELATION_TYPE_HUSBAND_OF_SISTER_OF_FATHER
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_FATHER -> RELATION_TYPE_SISTER_OF_FATHER
        RELATION_TYPE_BROTHER_OF_MOTHER -> RELATION_TYPE_WIFE_OF_BROTHER_OF_MOTHER
        RELATION_TYPE_WIFE_OF_BROTHER_OF_MOTHER -> RELATION_TYPE_BROTHER_OF_MOTHER
        RELATION_TYPE_SISTER_OF_MOTHER -> RELATION_TYPE_HUSBAND_OF_SISTER_OF_MOTHER
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_MOTHER -> RELATION_TYPE_SISTER_OF_MOTHER
        RELATION_TYPE_SISTER -> RELATION_TYPE_HUSBAND_OF_SISTER
        RELATION_TYPE_HUSBAND_OF_SISTER -> RELATION_TYPE_SISTER
        RELATION_TYPE_YOUNGER_BROTHER_OF_HUSBAND -> RELATION_TYPE_WIFI_OF_YOUNGER_BROTHER_OF_HUSBAND
        RELATION_TYPE_WIFI_OF_YOUNGER_BROTHER_OF_HUSBAND -> RELATION_TYPE_YOUNGER_BROTHER_OF_HUSBAND
        RELATION_TYPE_ELDER_BROTHER_OF_HUSBAND -> RELATION_TYPE_WIFI_OF_ELDER_BROTHER_OF_HUSBAND
        RELATION_TYPE_WIFI_OF_ELDER_BROTHER_OF_HUSBAND -> RELATION_TYPE_ELDER_BROTHER_OF_HUSBAND
        RELATION_TYPE_SISTER_OF_HUSBAND -> RELATION_TYPE_HUSBAND_OF_SISTER_OF_HUSBAND
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_HUSBAND -> RELATION_TYPE_SISTER_OF_HUSBAND
        RELATION_TYPE_BROTHER_OF_WIFI -> RELATION_TYPE_WIFE_OF_BROTHER
        RELATION_TYPE_SISTER_OF_WIFI -> RELATION_TYPE_HUSBAND_OF_SISTER_OF_WIFI
        RELATION_TYPE_HUSBAND_OF_SISTER_OF_WIFI -> RELATION_TYPE_SISTER_OF_WIFI
        else -> "$this's spouse"
    }
}
